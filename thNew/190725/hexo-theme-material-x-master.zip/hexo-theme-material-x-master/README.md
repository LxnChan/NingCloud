# Material X

一个简约的卡片式Hexo博客主题。

![](https://img.vim-cn.com/52/a54815c02ce232f11f54b2c547c1337828833c.png)



## 示例

[![](https://img.shields.io/badge/我的个人博客-https://xaoxuu.com/blog/-green.svg?colorA=888&colorB=52A1F8&longCache=true&style=popout-square)](https://xaoxuu.com/blog/)

[![](https://img.shields.io/badge/一个开源的示例博客-https://mxclub.github.io/example/-green.svg?colorA=888&colorB=52A1F8&longCache=true&style=popout-square)](https://mxclub.github.io/example/)


## 文档

[![](https://img.shields.io/badge/文档-https://xaoxuu.com/wiki/material--x/-green.svg?colorA=888&colorB=52A1F8&longCache=true&style=popout-square)](https://xaoxuu.com/wiki/material-x/)



## 图片预览

![](https://img.vim-cn.com/c6/349a2633dbfb842ea62ff9d810ca9b4a8dbb33.png)
![](https://img.vim-cn.com/8e/9ae699a4d7c8a7fa5a3007fc37e0b61b5b55bd.png)
![](https://img.vim-cn.com/bb/d3f01cd009b11025b453c697173855649d01a0.png)
![](https://img.vim-cn.com/6d/7a9f2a9360f6c8a4da9e00f5e1e8500ddbb223.png)
![](https://img.vim-cn.com/1e/fffd5955330a5d55c55401539da4bac77d5438.png)

![](https://img.vim-cn.com/71/f1e49674aac39f50c6a229c3d20225fc04af38.png)

![](https://img.vim-cn.com/5f/afab5382b2d9a4a64f3dc823b749551719b29a.png)

![](https://img.vim-cn.com/50/449e243ba625b2b7786a7e2ff9455b730356d3.png)
![](https://img.vim-cn.com/6c/29dbbf29005fba2c673fc636a65b5cdd1a1e01.png)
![](https://img.vim-cn.com/2d/edb556dd4e33f3d359a259ab1381906399606c.png)
